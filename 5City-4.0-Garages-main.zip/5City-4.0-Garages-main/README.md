# 📂 Garages Inspired on 5City 4.0 [ESX]
![image](https://github.com/user-attachments/assets/fc694eeb-add2-4d0f-b298-90751151ea61)

# Usage
```
TriggerEvent('fc-garage:openGarages')

exports['fc-garage']:OpenGarages()
```
